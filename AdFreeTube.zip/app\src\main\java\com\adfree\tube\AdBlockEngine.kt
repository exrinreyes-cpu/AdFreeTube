package com.adfree.tube

import android.net.Uri
import java.util.Locale

object AdBlockEngine {

    // Danh sách các domain và đường dẫn máy chủ quảng cáo phổ biến
    private val AD_HOST_PATTERNS = arrayOf(
        "googleads",
        "doubleclick.net",
        "googlesyndication.com",
        "adservice.google",
        "youtube.com/api/stats/ads",
        "youtube.com/pagead/",
        "youtube.com/ptracking",
        "youtube.com/get_midroll_info",
        "ad.doubleclick.net",
        "static.doubleclick.net",
        "adclick.g.doubleclick.net"
    )

    /**
     * Kiểm tra xem một URL có phải là tài nguyên quảng cáo cần chặn hay không
     */
    fun isAd(url: String?): Boolean {
        if (url.isNullOrEmpty()) return false
        val lowerUrl = url.lowercase(Locale.ROOT)
        
        for (pattern in AD_HOST_PATTERNS) {
            if (lowerUrl.contains(pattern)) {
                return true
            }
        }
        return false
    }

    /**
     * Đoạn JavaScript tự động vượt quảng cáo video và ẩn các banner quảng cáo
     */
    fun getAdBlockScript(): String {
        return """
        (function() {
            if (window.__adfree_injected) return;
            window.__adfree_injected = true;

            // 1. Chèn CSS ẩn hoàn toàn các thành phần banner và gợi ý quảng cáo
            const style = document.createElement('style');
            style.textContent = `
                .ad-showing, 
                .ad-interrupting, 
                .ytp-ad-module, 
                .ytp-ad-overlay-container,
                ytm-promoted-sparkles-web-renderer,
                ytm-promoted-video-renderer,
                #player-ads,
                .ytm-companion-ad-renderer,
                .ad-container,
                .ytp-ad-message-container,
                .ytp-ad-preview-container,
                ytm-paid-content-overlay-renderer,
                .sparkles-light-cta,
                ytm-mealbar-promo-renderer,
                ytm-upsell-dialog-renderer,
                .mobile-topbar-header-sign-in-button {
                    display: none !important;
                }
            `;
            document.head.appendChild(style);

            // 2. Hàm bỏ qua quảng cáo video tức thì
            function skipAd() {
                // Tự động bấm nút Bỏ qua quảng cáo (Skip Ads)
                const skipButtons = [
                    '.ytp-ad-skip-button',
                    '.ytp-ad-skip-button-modern',
                    '.videoAdUiSkipButton',
                    'button.ytp-ad-skip-button-slot',
                    '.ytp-ad-overlay-close-button',
                    '.ytp-skip-ad-button'
                ];

                for (const selector of skipButtons) {
                    const btn = document.querySelector(selector);
                    if (btn) {
                        btn.click();
                    }
                }

                // Nếu đang phát video quảng cáo (chưa có nút skip hoặc unskippable ad)
                const player = document.querySelector('.html5-video-player');
                if (player && (player.classList.contains('ad-showing') || player.classList.contains('ad-interrupting'))) {
                    const video = document.querySelector('video');
                    if (video && !isNaN(video.duration) && video.duration > 0) {
                        video.muted = true;
                        video.playbackRate = 16.0;
                        video.currentTime = video.duration - 0.1;
                    }
                }

                // Tự động đóng popup "Mở trong ứng dụng" hoặc "Dùng thử Premium"
                const dismissBtn = document.querySelector('ytm-button-renderer[dialog-dismiss], ytm-dialog-renderer .dialog-cancel-button');
                if (dismissBtn) {
                    dismissBtn.click();
                }
            }

            // Chạy liên tục kiểm tra quảng cáo mỗi 250ms
            setInterval(skipAd, 250);

            // Giữ cho video không bị dừng khi tab hoặc màn hình tắt
            document.addEventListener('visibilitychange', function(e) {
                e.stopImmediatePropagation();
            }, true);

            Object.defineProperty(document, 'hidden', { get: () => false });
            Object.defineProperty(document, 'visibilityState', { get: () => 'visible' });
        })();
        """.trimIndent()
    }
}
