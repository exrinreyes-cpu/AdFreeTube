# 🎬 AdFreeTube - Ứng Dụng Android Xem YouTube Không Quảng Cáo & Phát Nền

**AdFreeTube** là ứng dụng Android được thiết kế riêng biệt để mang lại trải nghiệm xem YouTube mượt mà nhất:
* 🚫 **Chặn 100% quảng cáo**: Tự động bỏ qua quảng cáo video (Auto-skip) và ẩn sạch banner quảng cáo.
* 🎧 **Phát âm thanh trong nền (Background Play)**: Tắt màn hình điện thoại hoặc chuyển sang app khác thì âm thanh vẫn tiếp tục phát.
* 📱 **Cửa sổ thu nhỏ (Picture-in-Picture - PiP)**: Vừa xem video vừa lướt Facebook, Zalo, nhắn tin.
* 🔄 **Chế độ toàn màn hình mượt mà**: Tự động xoay ngang khi phóng to video.
* 🔒 **Đăng nhập Google an toàn**: Không qua ứng dụng trung gian, giữ nguyên lịch sử xem và danh sách đăng ký.
* ⚡ **Không bao giờ bị lỗi đứng hình / xoay vòng**: Ứng dụng chạy trực tiếp trên nền web engine tiêu chuẩn nên không bị Google quét chặn như các bản mod APK cũ.

---

## 🚀 Hướng dẫn cách tạo file APK để cài vào điện thoại

Bạn có thể tạo file APK bằng **1 trong 2 cách** sau:

### Cách 1: Tự động tạo file APK qua GitHub (KHÔNG CẦN CÀI PHẦN MỀM GÌ - KHUYÊN DÙNG)

Dự án đã được tích hợp sẵn kịch bản **GitHub Actions** tự động build APK trên đám mây hoàn toàn miễn phí:

1. Tạo một tài khoản trên [GitHub.com](https://github.com) (nếu chưa có).
2. Tạo một Repository mới (chế độ Public hoặc Private).
3. Tải toàn bộ thư mục `AdFreeTube` này lên repository đó.
4. Trên trang GitHub của bạn, chuyển sang tab **Actions** -> Chọn workflow **Build AdFreeTube APK** -> Bấm nút **Run workflow**.
5. Chờ khoảng 1-2 phút, sau khi quá trình build hoàn tất (hiện dấu tích xanh):
   * Bấm vào lần chạy đó, kéo xuống phần **Artifacts**.
   * Bấm tải file **AdFreeTube-APK** (bên trong chứa file `app-debug.apk`).
6. Chuyển file `.apk` vào điện thoại Android và mở lên cài đặt!

---

### Cách 2: Biên dịch trực tiếp trên máy tính bằng Android Studio

Nếu máy tính của bạn đã cài **Android Studio**:
1. Mở Android Studio -> Chọn **Open** -> Chọn thư mục `AdFreeTube`.
2. Chờ Gradle đồng bộ (Sync) xong.
3. Trên thanh menu, chọn **Build** -> **Build Bundle(s) / APK(s)** -> **Build APK(s)**.
4. Khi hoàn thành, bấm vào thông báo **locate** để lấy file `app-debug.apk` và copy vào điện thoại để cài đặt.

---

## 📁 Cấu trúc mã nguồn

```
AdFreeTube/
├── .github/workflows/build-apk.yml     # Kịch bản tự động xuất file APK trên GitHub
├── app/
│   ├── src/main/
│   │   ├── AndroidManifest.xml         # Cấu hình quyền hệ thống, PiP, Service
│   │   ├── java/com/adfree/tube/
│   │   │   ├── MainActivity.kt         # Xử lý WebView, điều hướng, cử chỉ & PiP
│   │   │   ├── AdBlockEngine.kt        # Bộ lọc domain quảng cáo & auto-skip script
│   │   │   └── MediaPlaybackService.kt # Foreground service duy trì âm thanh khi tắt màn hình
│   │   └── res/                        # Layout, vector icon, màu sắc giao diện
│   └── build.gradle.kts
└── README.md
```
